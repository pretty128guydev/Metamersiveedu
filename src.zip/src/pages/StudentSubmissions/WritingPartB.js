import React from 'react';
import { StudentSubmissionMain } from "../../components/file-upload/file-upload";


const StudentSubmissionsWritingPartB = () => {
    return (<>
      <StudentSubmissionMain mock_paper_type="writing_part_b"/>
      </>
      )
}

export default StudentSubmissionsWritingPartB;