import React from 'react';

const TagGameAnalyticsDetail = () => {
    return (
        <div>
            <h2>Tag Game Analytics</h2>
        </div>
    );
};

export default TagGameAnalyticsDetail;